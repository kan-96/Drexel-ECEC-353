Homework 1
Khoa Nguyen
14295146

How To Compile & Run
====================
$ gcc -o primes primes.c

Found 359565 primes.
Last 5 primes found:
5171161         5171171         5171183         5171189         5171191
        ------------------------

Found 488979 primes.
Last 5 primes found:
7194727         7194731         7194739         7194751         7194773
        ------------------------
[kn574@xunil-03 ~]$ kill -s USR1 8877

Found 552786 primes.
Last 5 primes found:
8207197         8207207         8207237         8207249         8207273
        ------------------------
[kn574@xunil-03 ~]$ kill -s USR1 8877

Found 652546 primes.
Last 5 primes found:
9804283         9804299         9804317         9804331         9804337
        ------------------------
[kn574@xunil-03 ~]$ kill -s USR1 8877
Found 675033 primes.
Last 5 primes found:
10167977        10168013        10168019        10168033        10168043
        ------------------------
[kn574@xunil-03 ~]$ kill -s TERM 8877

Goodbye!




Description
===========
[Brief description of file(s)/program.]
First, I set signal block set, so SIGUSR!, SIGTERM, SIGALRM will not interupt my program update prime numbers in primes[]
If a prime number is found, it will be addd to primes[], and num_found + 1, then unmask sig block.

