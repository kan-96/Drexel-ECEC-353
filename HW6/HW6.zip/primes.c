/* Khoa Nguyen
ECEC 353 - Homework 6 */
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <limits.h>

#define NUM_PRIMES 10000000
#define FALSE 0
#define TRUE !FALSE

static unsigned int num_found;
static unsigned int primes[NUM_PRIMES];

int is_prime(unsigned int num)
{
    int i;

    if (num < 2) {
        return FALSE;
    }
    else if (num == 2) {
        return TRUE;
    }
    else if (num % 2 == 0) {
        return FALSE;
    }
    else {
        for (i=3; (i*i)<=num; i+=2) {
            if (num % i == 0) {
                return FALSE;
            }
        }
        return TRUE;
    }
}

void report()  {
    int i =0;
    printf("\nFound %lu primes.\n", num_found);
    printf("Last 5 primes found:\n");
    for (i = num_found - 5 ; i< num_found; i++)  {
        printf("%u \t", primes[i]);
    }
    printf("\n\t------------------------\t\n");
}

void handler (int sig)  {

    if (sig == SIGALRM) {
        alarm (10);
        report();
        
    }
    if (sig == SIGUSR1)  {
        report();
    }
    if (sig == SIGTERM) {
        printf("Goodbye!\n");
        exit (EXIT_SUCCESS);
    }
    
}



int main(int argc, char **argv)  {
    
    unsigned int num = 0;
    sigset_t block, prev_mask;
    sigemptyset(&block);
    sigaddset(&block, SIGALRM);
    sigaddset(&block, SIGUSR1);
    sigaddset(&block, SIGTERM);
      
    signal(SIGUSR1, handler);
    signal(SIGTERM, handler);
    signal (SIGALRM, handler);
    alarm(10);

    while (num_found < NUM_PRIMES) {
        
        sigprocmask(SIG_BLOCK,&block, &prev_mask);
        if (is_prime(num))  {
            primes[num_found++] = num;
        }
        num++;
        sigprocmask(SIG_SETMASK, &prev_mask, NULL);
            
    }

    return 0;
}