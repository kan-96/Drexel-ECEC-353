Homework 1
Khoa Nguyen
14295146

How To Compile & Run
====================
$ gcc -o control control.c
$ gcc -o worker worker.c
$ ./control
$ ./worker

[1833.76] <0> RESET
[2335.26] <0> PAUSE
[3863.58] <0> PRINT
[5465.25] <0> PRINT
[7891.67] <0> RESET
[8111.75] <0> PAUSE
[8520.06] <0> PAUSE
[9982.06] <0> PRINT
[10307.48] <0> PAUSE
[11114.85] <0> PRINT
[11763.78] <0> PAUSE
[12754.99] <0> PRINT
[13208.78] <0> PAUSE
^C
Reset
Current result: 0
Current result: 0
Reset
Current result: 0
Current result: 0
Current result: 0



Description
===========
[Brief description of file(s)/program.]
First, we create messeage queue, then open messqueue and send command into it.
Second, we open message queue with non-blocking mode from program worker.c
Using strncmp to compare commands between sending and recieving