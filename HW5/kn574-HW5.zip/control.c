/*Khoa - Nguyen
Homework5
Modified to send commands to a message queue
*/

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <mqueue.h>
#include <signal.h>

#define USE_PRIORITY 0

struct packet {
    char data[128];
    unsigned int prio;
    double timestamp;
};

int network_read(struct packet *pkt)
{
    static double time = 0.0;
    double delay, r;
    unsigned int cmd;

    char *commands[] = {"RUN", "PAUSE", "PRINT", "RESET"};

    r = rand() / (RAND_MAX + 1.0);
    delay = -log(1-r) / 0.001;
    time += delay;

    cmd = (int)((sizeof(commands)/sizeof(*commands)-1)*r+0.5);

    strcpy(pkt->data, commands[cmd]);
    pkt->timestamp = time;
#if (USE_PRIORITY == 1)
    pkt->prio = (unsigned int)(10*(rand()/(RAND_MAX+1.0)) + 1);
#else
    pkt->prio = 0;
#endif

    usleep(delay*1000.0);

    return 0;
}

int is_sigint = 0; 
char *buf = {"SHUTDOWN"};
mqd_t mqd;

void signal_handler(int sig )  {
    is_sigint = 1;
    mq_send(mqd, buf, strlen(buf), 9);
    printf("\nSending SHUTDOWN message.\n");
    mq_close(mqd);
    mq_unlink("/test_mq");
    printf("Shutting down\n");
    exit (EXIT_SUCCESS);
}

int main()
{   
    struct packet pkt;
    struct mq_attr attr;
    attr.mq_maxmsg = 10;
    attr.mq_msgsize = 100;
    
    
    
    mqd = mq_open ("/test_mq", O_CREAT | O_RDWR, 0600, &attr);
    if (mqd == -1)  {
        perror("mq_open()");
        exit(EXIT_FAILURE);
    }
    signal(SIGINT, signal_handler);

    while(1) {
      network_read(&pkt);
      mq_send(mqd, pkt.data, strlen(pkt.data), pkt.prio);
      printf("[%.2f] <%d> %s \n", pkt.timestamp, pkt.prio, pkt.data);
    }

    return 0;
}