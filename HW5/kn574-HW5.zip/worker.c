/*Khoa - Nguyen
Homework5
worker.c – The program is properly controlled by commands received from the message queue
*/

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mqueue.h>
#include <limits.h>
#include <signal.h>
#include <math.h>

int is_msg = 0;


void custome_handler(int sig)   {
    is_msg = 1;
}
int main () 
{    
    struct mq_attr attr;
    mqd_t mqd; 
    struct sigevent sev;
    unsigned int prio;
    unsigned int i; 
    int nbytes;
    char *buf;

    mqd =  mq_open("/test_mq", O_RDONLY | O_NONBLOCK);
    if (mqd == -1)  {
        perror("mq_open()");
        exit(EXIT_FAILURE);
    }

    mq_getattr(mqd, &attr);
    buf = malloc(attr.mq_msgsize);

    sev.sigev_notify = SIGEV_SIGNAL;
    sev.sigev_signo = SIGUSR1;
    mq_notify(mqd, &sev);
    signal(SIGUSR1, custome_handler);

    int running = 0;
    unsigned long int total = 0;
    unsigned long int result = 0;
    

    for ( i =0 ; i < UINT_MAX ; i++)    {
        total += i ;
        
        if (is_msg) {
            while ((nbytes = mq_receive(mqd, buf, attr.mq_msgsize, &prio)) >= 0 ) {
                if (strncmp(buf, "PAUSE",nbytes) == 0)    {
                    if (running == 1) {
                        result = total;
                        running = 0;
                        printf("\n[PAUSED]");
                        fflush(stdout);
                    }
                    sleep(1);
                }
                else if (strncmp(buf, "RESET",nbytes) == 0)  {
                    total = 0;
                    result = 0;
                    i = 0;
                    printf("\nReset");
                    fflush(stdout);
                    if ( running == 0)  {
                        sleep(1);
                    }
                }
                else if (strncmp(buf,"RUN",nbytes) == 0 )  {
                    if (running == 0)  {
                        running = 1;
                        printf("\n>>RUNNING<<");
                        fflush(stdout);
                    }
                }
                else if ((strncmp(buf, "PRINT", nbytes) == 0)) {
                    if (running == 1) {
                        result = total;
                    }
                    printf("\nCurrent result: %ld", result);
                    fflush(stdout);
                    
                    
                }
                else if (strncmp(buf, "SHUTDOWN", nbytes))  {
                    printf("\nShutting down\n");
                    mq_close(mqd);
                    mq_unlink("/test_mq");
                    exit (EXIT_SUCCESS);
                }
            }
            mq_notify(mqd, &sev);
            is_msg = 0;
        }
        sleep(1);     
    }
    return 0;
}